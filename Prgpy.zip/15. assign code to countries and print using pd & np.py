#!/usr/bin/env python
# coding: utf-8

# In[6]:


import numpy as np
import pandas as pd
labels = ['a','b','c']
my_list = [10,20,30]
arr = np.array([10,20,30])
d = {'a' : 10, 'b' : 20, 'c' : 30}
pd.Series(data=my_list)
pd.Series(d)
ser1 = pd.Series([1,2,3,4],index = ['USA', 'Germany','USSR','Japan'])
ser1


# In[ ]:




